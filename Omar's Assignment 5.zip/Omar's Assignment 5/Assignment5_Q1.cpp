#include <iostream>
#include <stack>
using namespace std;

struct Node {
    int data;
    Node* next;
};
typedef Node* NodePtr;

// Print the Linked List:
void PrintList(Node* head) {
    Node *current = head;
    while (current != nullptr) {
        cout << current -> data << "\t";
        current = current -> next;
    }
    cout << endl;
}

// Print the Linked List in Reverse using a Stack Class:
void PrintListInReverse(Node* head) {
    stack<Node*> s;
    Node *current = head;
    while (current != nullptr) {
        s.push(current);
        current = current -> next;
    }
    while (!s.empty()) {
        current = s.top();
        s.pop();
        cout << current -> data << "\t";
    }
    cout << endl;
}

// Reverse the Linked List using a Stack Class:
Node* Reverse(Node* head) {
    stack<Node*> s;
    Node *current = head;
    while (current != nullptr) {
        s.push(current);
        current = current -> next;
    }
    Node* NewHead = s.top();
    s.pop();
    current = NewHead;
    while (!s.empty()) {
        current -> next = s.top();
        s.pop();
        current = current -> next;
    }
    current -> next = NULL;
    return NewHead;
}

// Find the Middle Node of a Linked List:
Node* MiddleNode(Node* head) {
    Node *middle_node = head;
    Node *end = head;
    while (end != nullptr && end -> next != nullptr) {
        middle_node = middle_node -> next;
        end = end -> next -> next;
    }
    return middle_node;
}

// Merge 2 sorted lists:
Node* Merge(Node* head1, Node* head2) {
    if (head1 == NULL) {
        return head2;
    }
    if (head2 == NULL) {
        return head1;
    }
    Node* Merged_Head = NULL;
    if (head1 -> data < head2 -> data) {
        Merged_Head = head1;
        head1 -> next = Merge(head1 -> next, head2);
    } else {
        Merged_Head = head2;
        head2 -> next = Merge(head2 -> next, head1);
    }
    return Merged_Head;
}

// Traverse down the list, removing all nodes that matches the element you want to remove:
Node* RemoveNodes(Node* head, int target) {
    Node *current = head;
    while (head != nullptr && head -> data == target) {
        head = head -> next;
    }
    while (current != nullptr && current -> next != nullptr) {
        if (current -> next -> data == target) {
            current -> next = current -> next -> next;
        } else {
            current = current -> next;
        }
    }
    return head;
}


int main() {

    // Creating a linked list
    NodePtr my_list = new Node{1, nullptr};
    my_list -> next = new Node{2, nullptr};
    my_list -> next -> next = new Node{3, nullptr};
    my_list -> next -> next -> next = new Node{4, nullptr};
    my_list -> next -> next -> next -> next = new Node{5, nullptr};

    // Print the linked list
    cout << "Original Linked List: " << endl;
    PrintList(my_list);

    cout << "------------------------------------------------------" << endl;

    // Print the linked list in reverse order
    cout << "Linked List in Reverse Order: " << endl;
    PrintListInReverse(my_list);

    cout << "------------------------------------------------------" << endl;

    // Reverse the linked list
    my_list = Reverse(my_list);
    cout << "Reversed Linked List: " << endl;
    PrintList(my_list);

    cout << "------------------------------------------------------" << endl;

    // Find the middle node of the linked list
    Node *middle = MiddleNode(my_list);
    cout << "The Middle Node of the Linked List is: " << endl;
    cout << middle -> data << endl;

    cout << "------------------------------------------------------" << endl;

    // Merge two sorted linked lists
    NodePtr List1 = new Node{1, new Node{3, new Node{5, nullptr}}};
    NodePtr List2 = new Node{2, new Node{4, new Node{6, nullptr}}};
    Node* merged_list = Merge(List1, List2);
    cout << "Merged Linked List: " << endl;
    PrintList(merged_list);

    cout << "------------------------------------------------------" << endl;

    // Remove nodes with data = 4 from the linked list
    Node* list_after_removal = RemoveNodes(my_list, 4);
    cout << "Linked List After Removing Nodes With Data Equal To 4: " << endl;
    PrintList(list_after_removal);

    cout << "------------------------------------------------------" << endl;

    return 0;

}
