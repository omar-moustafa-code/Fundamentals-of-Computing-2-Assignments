#include <iostream>
#include <stack>
using namespace std;

template <class DataType>

class Stack {
private:
    struct Node {
        DataType data;
        Node* next;
    };
    Node* top;
public:
    Stack() {
        top = NULL;
    }
    ~Stack() {
        while(!StackIsEmpty()) {
            Pop();
        }
    }
    void Push(DataType v) {
        Node* newNode = new Node;
        newNode -> data = v;
        newNode -> next = top;
        top = newNode;
    }
    void Pop() {
        if (StackIsEmpty()) {
            cout << "Stack Underflow!" << endl;
        } else {
            Node* temp = top;
            top = top -> next;
            delete temp;
        }
    }
    bool StackIsEmpty() const {
        return (top == NULL);
    }
    bool StackIsFull() const {
        return false;
    }
    void DisplayStack() {
        if (StackIsEmpty()) {
            cout << "Stack Is Empty!" << endl;
        } else {
            Node* temp = top;
            while (temp != NULL) {
                cout << temp -> data << endl;
                temp = temp -> next;
            }
        }
    }
    DataType GetTop() const {
        if (StackIsEmpty()) {
            cout << "Stack is empty" << endl;
        } else {
            return top -> data;
        }
    }


};

int main() {

    Stack <int> s;

    s.Push(1);
    s.Push(2);
    s.Push(3);
    s.Push(4);
    s.Push(5);

    cout << "The Stack Before Any Popping: " << endl;

    s.DisplayStack();

    cout << "------------------------------" << endl;

    if (s.StackIsEmpty()) {
        cout << "The Stack Is Empty!" << endl;
    } else {
        cout << "The Stack Is NOT Empty!" << endl;
    }

    cout << "------------------------------" << endl;

    while (!s.StackIsEmpty()) {
        cout << s.GetTop() << " Has Been Popped!" << endl;
        s.Pop();
    }

    cout << "------------------------------" << endl;

    cout << "The Stack Is Now Empty! " << endl;

    cout << "------------------------------" << endl;

    return 0;

}
