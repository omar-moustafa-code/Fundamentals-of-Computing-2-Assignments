#include <iostream>
#include <stack>
using namespace std;

int ExistingOperator(char operation) {
    if (operation == '+' || operation == '-') {
        return 1;
    } else if (operation == '*' || operation == '/') {
        return 2;
    } else if (operation == '^') {
        return 3;
    }
}

string InfixToPostfix(string str) {
    stack <char> s;
    s.push('(');
    str = str + ')';

    string postfix = "";

    int L = str.length();

    for (int i = 0; i < L; i++) {
        if (str[i] == ' ') {
            continue;
        } else if (isdigit(str[i]) || isalpha(str[i])) {
            postfix = postfix + str[i];
        } else if (str[i] == '(') {
            s.push(str[i]);
        } else if (str[i] == ')') {
            while (s.top() != '(') {
                postfix = postfix + s.top();
                s.pop();
            }
            s.pop();
        } else {
            while (s.top() != '(' && ExistingOperator(str[i]) <= ExistingOperator(s.top())) {
                postfix = postfix + s.top();
                s.pop();
            }
            s.push(str[i]);
        }
    }

    cout << "The New Postfix Expression Is: " << endl;

    return postfix;
}

int main() {

    string infix = "a + b * c - (d / e + f) * g";

    cout << "The Original Infix Expression Is: " << endl;

    cout << infix << endl;

    cout << "---------------------------------" << endl;

    string postfix = InfixToPostfix(infix);

    cout << postfix << endl;

    cout << "---------------------------------" << endl;

    cout << endl;

    return 0;

}
