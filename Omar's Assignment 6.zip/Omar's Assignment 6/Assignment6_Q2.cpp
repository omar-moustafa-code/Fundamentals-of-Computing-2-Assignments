#include <iostream>
#include <string>
using namespace std;

enum sType {integer, real, boolean, character};

struct Symbol {
    string name;
    sType type;
    int address;
    Symbol *left_node;
    Symbol *right_node;
};

class ST {
private:
    Symbol *root;
    Symbol *CreateNode(string name) {
        Symbol *node = new Symbol;
        node -> name = name;
        node -> type = integer;
        node -> address = 0;
        node -> left_node = NULL;
        node -> right_node = NULL;
        return node;
    }
    
    void DeleteTree(Symbol *node) {
        if (node == NULL) {
            return;
        } else {
            delete node;
        }
    }
    
public:
    ST() {
        root = NULL;
    }
    
    ~ST() {
        DeleteTree(root);
    }
    
    Symbol *CreateEntry(string name) {
        if (root == nullptr) {
            root = CreateNode(name);
            return root;
        }
        Symbol* current_node = root;
        while (true) {
            if (name == current_node -> name) {
                return current_node;
            }
            else if (name < current_node->name) {
                if (current_node -> left_node == nullptr) {
                    current_node -> left_node = CreateNode(name);
                    return current_node -> left_node;
                }
                else {
                    current_node = current_node -> left_node;
                }
            }
            else {
                if (current_node -> right_node == nullptr) {
                    current_node -> right_node = CreateNode(name);
                    return current_node -> right_node;
                }
                else {
                    current_node = current_node -> right_node;
                }
            }
        }
    }
    
    void InsertType(Symbol *index, sType my_type) {
        index -> type = my_type;
    }
    
    void InsertAddress(Symbol *index, int my_address) {
        index -> address = my_address;
    }
    
    sType GetType(Symbol *index) {
        return index -> type;
    }
    
    int GetAddress(Symbol* index) {
        return index -> address;
    }
    
    Symbol* Lookup(string name) {
        Symbol *current_node = root;
        while (current_node != NULL) {
            if (name == current_node -> name) {
                cout << "Current Node: " << endl;
                return current_node;
            }
            else if (name < current_node -> name) {
                current_node = current_node -> left_node;
            }
            else {
                current_node = current_node -> right_node;
            }
        }
        return NULL;
    }
    
    void TraverseTree(Symbol *node) {
        if (node == NULL) {
            return;
        }
        TraverseTree(node -> left_node);
        cout << "Name: " << node -> name << endl;
        cout << "Type: " << node -> type << endl;
        cout << "Address: " << node -> address << endl;
        cout << "--------------------------" << endl;
        TraverseTree(node -> right_node);
    }
    
    void PrintAll() {
        TraverseTree(root);
    }
};

int main() {

    ST my_table;

    Symbol symbols[] = {
            {"Integer", integer, 10},
            {"Real", real, 20},
            {"Boolean", boolean, 30},
            {"Character", character, 40},
            {"$$$", integer, 0}
    };

    int i = 0;
    
    while (true) {
        string my_str = symbols[i].name;
        if (my_str == "$$$") {
            break;
        }
        sType my_type = symbols[i].type;
        int symbol_address = symbols[i].address;
        Symbol *symbol = my_table.CreateEntry(my_str);
        my_table.InsertType(symbol, my_type);
        my_table.InsertAddress(symbol, symbol_address);
        i = i + 1;
    }

    cout << "ALl Existing Information: " << endl;
    cout << "--------------------------" << endl;
    
    my_table.PrintAll();

    return 0;

}

