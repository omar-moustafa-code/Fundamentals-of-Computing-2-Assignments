#include <iostream>
#include <vector>
using namespace std;

enum sType {integer, real, boolean, character};

struct Symbol {
    string name;
    sType type;
    int address;
};

class ST {
private:
    vector <Symbol> v;
    int ST_size;
public:
    ST() {
        ST_size = 128;
        v.resize(ST_size);
        for (int i = 0; i < ST_size; i++) {
            v[i].name = "";
            v[i].address = 0;
        }
    }
    ~ST() {
        v.clear();
    }

    int hashFn(string name) {
        int hash = 0;
        for (int i = 0; i < name.length(); i++) {
            hash = hash + name[i];
        }
        return hash % ST_size;
    }

    int CreateEntry(string name) {
        int hash = hashFn(name);
        int index = hash;
        while (v[index].name != "") {
            index = (index + 1) % ST_size;
            if (index == hash) {
                cout << "Symbol Table Is Full!" << endl;
                return -1;
            }
        }
        v[index].name = name;
        return index;
    }

    void InsertType(int index, sType t) {
        v[index].type = t;
    }

    void InsertAddress(int index, int my_address) {
        v[index].address = my_address;
    }

    sType GetType(int index) {
        return v[index].type;
    }

    int GetAddress(int index) {
        return v[index].address;
    }

    int Lookup(string name) {
        int hash = hashFn(name);
        int index = hash;
        while (v[index].name != name) {
            index = (index + 1) % ST_size;
            if (index == hash) {
                return -1;
            }
        }
        return index;
    }

    void PrintAll() {
        for (int i = 0; i < ST_size; i++) {
            if (v[i].name != "") {
                cout << "Name: " << v[i].name << endl;
                cout << "Data Type: " << v[i].type << endl;
                cout << "Address: " << v[i].address << endl;
                cout << "Index: " << i << endl;
                cout << "Hash Value: " << hashFn(v[i].name) << endl;
                cout << "--------------------------" << endl;
            }
        }
    }

};

int main() {

    ST Table;

    vector<vector<string>> info = {
            {"Integer", "integer", "10"},
            {"Real", "real", "20"},
            {"Boolean", "boolean", "30"},
            {"Character", "character", "40"},
            {"$$$", "", ""}
    };

    for (int i = 0; i < info.size(); i++) {
        if (info[i][0] == "$$$") {
            break;
        }
        string my_name = info[i][0];
        sType my_type;
        if (info[i][1] == "integer") {
            my_type = integer;
        } else if (info[i][1] == "real") {
            my_type = real;
        } else if (info[i][1] == "boolean") {
            my_type = boolean;
        } else if (info[i][1] == "character") {
            my_type = character;
        }
        int my_address = stoi(info[i][2]);
        int index = Table.CreateEntry(my_name);
        if (index == -1) {
            return 0;
        }
        Table.InsertType(index, my_type);
        Table.InsertAddress(index, my_address);
    }

    cout << "All Existing Information: " << endl;
    cout << "--------------------------" << endl;
    Table.PrintAll();

    return 0;

}
