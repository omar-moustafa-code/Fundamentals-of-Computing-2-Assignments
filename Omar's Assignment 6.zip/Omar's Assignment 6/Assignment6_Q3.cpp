#include <iostream>
#include <queue>
#include <ctime>
using namespace std;

struct Customer {
    int customer_number;
    time_t time_of_arrival;
    time_t time_of_departure;
};

int TimeDifference(time_t start, time_t end) {
    cout << "The Difference In Time Is: " << endl;
    return difftime(end, start);
}

int main() {

    queue <Customer> customer_queue;
    
    queue <int> wait_times;
    
    int ticket_number = 1;

    while (true) {
    
        int my_choice;
        
        cout << "Enter: " << endl;
        cout << "1 - To Simulate Customer Arrival. " << endl;
        cout << "2 - To Assist The Next Customer. " << endl;
        cout << "3 - To Exit. " << endl;
        cout << "----------------------------------" << endl;

        cin >> my_choice;

        if (my_choice == 1) {
            Customer my_customer;
            my_customer.customer_number = ticket_number++;
            my_customer.time_of_arrival = time(NULL);
            customer_queue.push(my_customer);
            cout << "Customer #" << my_customer.customer_number << " Entered At: " << my_customer.time_of_arrival << endl;
        }
        else if (my_choice == 2) {
            if (customer_queue.empty()) {
                cout << "Empty Queue!" << endl;
            } else {
                Customer my_customer = customer_queue.front();
                customer_queue.pop();
                my_customer.time_of_departure = time(NULL);

                int wait_time = TimeDifference(my_customer.time_of_arrival, my_customer.time_of_departure);
                wait_times.push(wait_time);

                if (wait_times.size() > 3) {
                    wait_times.pop();
                }

                int total_wait_time = 0;
                
                for (int i = 0; i < wait_times.size(); i++) {
                    total_wait_time += wait_times.front();
                    wait_times.push(wait_times.front());
                    wait_times.pop();
                }
                
                double average_wait_time;
                average_wait_time = total_wait_time / wait_times.size();

                cout << "Customer #" << my_customer.customer_number << " Is Being Helped At: " << my_customer.time_of_departure << endl;
                cout << "The Current Wait Time Is: " << wait_time << endl;
                cout << "The Wait Time For The Upcoming Customer Is: " << average_wait_time << endl;
            	cout << "----------------------------------" << endl;

            }
        } else if (my_choice == 3) {
            cout << "Log Of All Served Customers:" << endl;
            while (!customer_queue.empty()) {
                Customer my_customer = customer_queue.front();
                customer_queue.pop();
                my_customer.time_of_departure = time(NULL);
                cout << "Customer #" << my_customer.customer_number << ": " << endl;
                cout << "Their Arrival Time: " << my_customer.time_of_arrival << endl;
                cout << "Their Departure Time: " << my_customer.time_of_departure << endl;
                cout << "----------------------------------" << endl;
            }
            break;
        } else {
            cout << "Invalid Input." << endl;
        }
    }

    return 0;

}
