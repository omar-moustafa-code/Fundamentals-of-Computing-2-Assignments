#include <iostream>
using namespace std;

class Matrix {
private:
    int rows;
    int columns;
    int *matrix;
public:
    Matrix() {

    }

    Matrix(int the_rows, int the_columns) {
        rows = the_rows;
        columns = the_columns;
        matrix = new int(rows * columns);
    }

    void setRows(int r) {
        rows = r;
    }

    void setColumns(int c) {
        columns = c;
    }

    void setElement(int the_row, int the_column, int value) {
         *(matrix + the_row * columns + the_column) = value;
    }

    int getRows() const {
        return rows;
    }

    int getColumns() const {
        return columns;
    }

    int getElement(int the_row, int the_column) const {
        return *(matrix + the_row * columns + the_column);
    }

    void ReadMatrix() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                cin >> *(matrix + i * columns + j);
            }
        }
    }

    void DisplayMatrix() const {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                cout << *(matrix + i * columns + j) << "\t";
            }
            cout << endl;
        }
    }

    Matrix operator * (const Matrix &m) {
        Matrix product = Matrix(rows, columns);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < m.getColumns(); j++) {
                int sum = 0;
                for (int k = 0; k < m.getColumns(); k++) {
                    sum = sum + *(matrix + i * columns + k) * m.getElement(k, j);
                }
                product.setElement(i, j, sum);
            }
        }
        return product;
    }

    Matrix operator / (const int &x) {
        Matrix quotient = Matrix(rows, columns);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                int value = *(matrix + i * columns + j) / x;
                quotient.setElement(i, j, value);
            }
        }
        return quotient;
    }

    Matrix operator + (const Matrix &m) {
        Matrix sum = Matrix(rows, columns);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                int value = *(matrix + i * columns + j) + m.getElement(i, j);
                sum.setElement(i, j, value);
            }
        }
        return sum;
    }

    Matrix operator - (const Matrix &m) {
        Matrix difference = Matrix(rows, columns);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                int value = *(matrix + i * columns + j) - m.getElement(i, j);
                difference.setElement(i, j, value);
            }
        }
        return difference;
    }

    Matrix operator = (const Matrix &m) {
        Matrix assignment = Matrix(rows, columns);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                int value = *(matrix + i * columns + j);
                assignment.setElement(i, j , value);
            }
        }
        return assignment;
    }

};


int main() {

    Matrix a =  Matrix(2, 2);
    a.setElement(0, 0, 1);
    a.setElement(0, 1, 2);
    a.setElement(1, 0, 3);
    a.setElement(1, 1, 4);
    cout << "Matrix A: " << endl;
    a.DisplayMatrix();
    cout << "--------------------" << endl;

    Matrix b = Matrix(2, 2);
    b.setElement(0, 0, 5);
    b.setElement(0, 1, 6);
    b.setElement(1, 0, 7);
    b.setElement(1, 1, 8);
    cout << "Matrix B: " << endl;
    b.DisplayMatrix();
    cout << "--------------------" << endl;

    Matrix c = a + b;
    cout << "Matrix a + Matrix b: " << endl;
    c.DisplayMatrix();
    cout << "--------------------" << endl;

    Matrix d = a - b;
    cout << "Matrix a - Matrix b: " << endl;
    d.DisplayMatrix();
    cout << "--------------------" << endl;

    Matrix e = a * b;
    cout << "Matrix a * Matrix b: " << endl;
    e.DisplayMatrix();
    cout << "--------------------" << endl;

    Matrix f = a / 2;
    cout << "Matrix a / 2: " << endl;
    f.DisplayMatrix();
    cout << "--------------------" << endl;

    cout << "Assignment Operator: " << endl;
    Matrix g = a;
    g.DisplayMatrix();
    cout << "--------------------" << endl;

    return 0;
}
