#include <iostream>
using namespace std;

class rational {
private:
    int num;
    int denom;
public:
    rational() {

    }

    rational(int denom) {
        denom = 1;
    }

    rational(int n, int d) {
        num = n;
        denom = d;
    }

    void setNum(int n) {
        num = n;
    }

    void setDenom(int d) {
        denom = d;
    }

    int getNum() const {
        return num;
    }

    int getDenom() const {
        return denom;
    }

    // Reduce fraction
    rational reduce() const {
        int gcd;
        for (int i = 1; i <= num; i++) {
            if (num % i == 0 && denom % i == 0) {
                gcd = i;
            }
        }
        int new_num = num/gcd;
        int new_denom = denom/gcd;
        return {new_num, new_denom};
    }

    // Multiply fractions
     rational multiply(const rational &f) {
        int new_num = num * f.num;
        int new_denom = denom * f.denom;
        return {new_num, new_denom};
    }

    // Divide fractions
    // Multiplying by the reciprocal
    rational divide(const rational &f) {
        int new_num = num * f.denom;
        int new_denom = denom * f.num;
        return {new_num, new_denom};
    }

    // Add Fractions
    rational add(const rational &f) {
        int new_num, new_denom;
        if (f.denom != denom) {
            new_num = (num * f.denom) + (f.num * denom);
            new_denom = denom * f.denom;
        } else {
            new_denom = denom;
            new_num = num * f.denom;
        }
        return {new_num, new_denom};
    }

    // Subtract Fractions
    rational subtract(const rational &f) {
        int new_num, new_denom;
        if (f.denom != denom) {
            new_num = (num * f.denom) - (f.num * denom);
            new_denom = denom * f.denom;
        } else {
            new_denom = denom;
            new_num = num - f.num;
        }
        return {new_num, new_denom};
    }

    // Read a fraction
    void readRational() {
        char slash;
        cout << "Enter the numerator: " << endl;
        cin >> num;
        cout << "Enter the slash: " << endl;
        cin >> slash;
        cout << "Enter the denominator: " << endl;
        cin >> denom;
    }

    // Display a fraction
    void displayRational() const {
        cout << num << "/" << denom << endl;
    }

    // Operator Style
    // Test equality of object and parameter
    bool operator == (const rational &f) {
        if (num == f.num && denom == f.denom) {
            return true;
        } else {
            return false;
        }
    }

    bool operator < (const rational &f) {
        if (num < f.num && denom < f.denom) {
            return true;
        } else {
            return false;
        }
    }

    bool operator > (const rational &f) {
        if ((num / denom) > (f.num / f.denom)) {
            return true;
        } else {
            return false;
        }
    }

    bool operator <= (const rational &f) {
        if ((num / denom) <= (f.num / f.denom)) {
            return true;
        } else {
            return false;
        }
    }

    bool operator >= (const rational &f) {
        return (num * f.denom >= denom * f.num);
    }

};

int main() {

    rational a;
    a.setNum(1);
    a.setDenom(2);
    cout << "Fraction a: " << endl;
    a.displayRational();
    cout << "--------------------------------------" << endl;

    rational b;
    b.setNum(2);
    b.setDenom(3);
    cout << "Fraction b: " << endl;
    b.displayRational();
    cout << "--------------------------------------" << endl;

    rational c = a.add(b);
    cout << "Fraction a + Fraction b: " << endl;
    c.displayRational();
    cout << "--------------------------------------" << endl;

    rational d = a.subtract(b);
    cout << "Fraction a - Fraction b: " << endl;
    d.displayRational();
    cout << "--------------------------------------" << endl;

    rational e = a.multiply(b);
    cout << "Fraction a * Fraction b: " << endl;
    e.displayRational();
    cout << "--------------------------------------" << endl;

    rational f = a.divide(b);
    cout << "Fraction a / Fraction b: " << endl;
    f.displayRational();
    cout << "--------------------------------------" << endl;

    cout << "Boolean Operator: Is a equal to b?" << endl;
    bool is_equal = b == a;
    cout << is_equal << endl;
    cout << "--------------------------------------" << endl;

    cout << "Boolean Operator: Is a less than to b?" << endl;
    bool less_than = a < b;
    cout << less_than << endl;
    cout << "--------------------------------------" << endl;

    cout << "Boolean Operator: Is a greater than b?" << endl;
    bool greater_than = a > b;
    cout << greater_than << endl;
    cout << "--------------------------------------" << endl;

    cout << "Boolean Operator: Is a less than or equal to b?" << endl;
    bool less_than_or_equal_to = a <= b;
    cout << less_than_or_equal_to << endl;
    cout << "--------------------------------------" << endl;

    cout << "Boolean Operator: Is a greater than or equal to b?" << endl;
    bool greater_than_or_equal_to = a >= b;
    cout << greater_than_or_equal_to << endl;
    cout << "--------------------------------------" << endl;

    return 0;
}
