#include <iostream>
using namespace std;

int * rarray() {
    int n;
    cout << "Enter the size for a 1D integer array: " << endl;
    cin >> n;
    int array[n];

    for (int i = 0; i < n; i++) {
        array[i] = rand() % 2;
    }
    cout << " " << endl;
    cout << "1D array containing a random sequence of zeroes and ones: " << endl;
    for (int i = 0; i < n; i++) {
        cout << array[i] << "\t";
    }
    cout << endl;

    int *ptr = array;

    return ptr;

}

int main() {
    int *p;
    p = rarray();
    cout << " " << endl;
    cout << "Here is the pointer: " << endl;
    cout << p << endl;

    return 0;
}
