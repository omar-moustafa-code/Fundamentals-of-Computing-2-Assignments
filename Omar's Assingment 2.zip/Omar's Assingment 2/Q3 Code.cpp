#include <iostream>
using namespace std;

void UpperDiagonal(int N, int two_dim[][4], int one_dim[]) {
    int k = 0;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < 4; j++) {
            if (i <= 2 && j >= 1) {
                one_dim[k] = two_dim[i][j];
                k++;
            }
        }
    }
}

const int N = 4;

int main() {
    int two[][4] = {{9, 13, 5, 2},
                    {1, 11, 7, 6},
                    {3, 7, 4, 1},
                    {6, 0, 7, 10}};

    int one[6];

    UpperDiagonal(N, two, one);

    cout << "Here's 1D Run-Time Array Containing Just Upper Diagonal Elements: " << endl;

    for (int i = 0; i < 6; i++) {
        cout << one[i] << "\t";
    }
    cout << endl;

    return 0;
}
