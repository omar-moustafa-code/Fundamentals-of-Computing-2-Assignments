#include <iostream>
using namespace std;

struct Item {
    float weight;
    float price;
};

Item Maxval(Item item1, Item item2) {
    float item1_price_per_weight = item1.price / item1.weight;

    float item2_price_per_weight = item2.price / item2.weight;

    cout << "Item 1 Price Per Weight Ratio: " << item1_price_per_weight << endl;
    cout << " " << endl;
    cout << "Item 2 Price Per Weight Ratio: " << item2_price_per_weight << endl;
    cout << " " << endl;
    if (item1_price_per_weight > item2_price_per_weight) {
        cout << "So, Item 1 is the item with the higher price per weight ratio." << endl;
    } else if (item2_price_per_weight > item1_price_per_weight) {
        cout << "So, Item 2 is the item with the higher price per weight ratio." << endl;
    } else {
        cout << "So, both items have the same price per weight ratio." << endl;
    }
}

int main() {
    Item item1, item2;

    item1.price = 4.50;
    item1.weight = 2.30;

    item2.price = 5.50;
    item2.weight = 1.20;


    Maxval(item1, item2);

    return 0;
}
