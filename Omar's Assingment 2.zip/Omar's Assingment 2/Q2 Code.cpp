#include <iostream>
using namespace std;

void Copy(int N, int M, int two_dimensional[][3], int one_dimensional[]) {
    int k = 0;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            one_dimensional[k] = two_dimensional[i][j];
            k++;
        }
    }
}

int main() {
    const int N = 2;
    const int M = 3;
    int two_dim[N][M] = {{1, 2, 3},
                         {4, 5, 6}};
    int L = N * M;
    int one_dim[L];

    cout << "Here is the Original 2D Array: " << endl;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            cout << two_dim[i][j] << "\t";
        }
        cout << endl;
    }

    cout << "-------------------------------" << endl;
    Copy(N, M , two_dim, one_dim);

    cout << "Here is the Copied 1D Array: " << endl;
    for (int i = 0; i < L; i++) {
        cout << one_dim[i] << "\t";
    }
    cout << endl;

    return 0;
}
