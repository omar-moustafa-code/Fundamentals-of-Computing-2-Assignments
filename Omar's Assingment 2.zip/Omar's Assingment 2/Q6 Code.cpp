#include <iostream>
using namespace std;

struct Complex {
    double real;
    double imaginary;
};

Complex cmult(Complex a, Complex b) {
    Complex c;
    c.real = a.real * b.real - a.imaginary * b.imaginary;
    c.imaginary = a.real * b.imaginary + b.real * a.imaginary;
    return c;
}

void Display(Complex c) {
    if (c.imaginary >= 0) {
        cout << "The result of the complex multiplication is: " << endl;
        cout << c.real << " + " << c.imaginary << "j" << endl;
    } else {
        cout << "The result of the complex multiplication is: " << endl;
        cout << c.real << " - " << (c.imaginary) << "j" << endl;
    }
}


int main() {

    Complex a, b, c;
    a.real = 1;
    a.imaginary = 2;
    b.real = 3;
    b.imaginary = 4;

    c = cmult(a, b);
    Display(c);

    return 0;
}
