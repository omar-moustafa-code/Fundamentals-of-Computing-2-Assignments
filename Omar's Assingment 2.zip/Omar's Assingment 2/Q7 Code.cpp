#include <iostream>
using namespace std;

struct Fraction {
    int num;
    int denom;
};

Fraction fadd(Fraction x, Fraction y) {
    // z = x + y
    // if x = a/b and y = c/d -> z = (a * d + c *b) / (b * d)
    int numerator_z;
    numerator_z = x.num * y.denom + y.num * x.denom;
    int denominator_z;
    denominator_z = x.denom * y.denom;
    Fraction z = {numerator_z, denominator_z};
    return z;
}

int main() {

    Fraction x, y, z;
    x.num = 1;
    x.denom = 2;
    cout << "X is: " << x.num << "/" << x.denom << endl;
    cout << " " << endl;
    y.num = 1;
    y.denom = 3;
    cout << "Y is: " << y.num << "/" << y.denom << endl;
    cout << " " << endl;

    z = fadd(x, y);
    cout << "So the result of Z is: " << z.num << "/" << z.denom << endl;

    return 0;
}
