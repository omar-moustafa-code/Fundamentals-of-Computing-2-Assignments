#include <iostream>
using namespace std;

int main() {
    int size = 10;
    char *char_array = new char (size);

    for (int i = 0; i < size; i++) {
        cout << "Enter a Character for Dynamic Array Element " << i+1 << ": " << endl;
        cin >> char_array[i];
    }

    cout << "Here is the Dynamic Array of Characters: " << endl;
    for (int i = 0; i < size; i++) {
        cout << char_array[i] << "\t";
    }
    cout << endl;

    delete char_array;

    return 0;
}