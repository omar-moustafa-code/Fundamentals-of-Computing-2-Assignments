#include <iostream>
#include <cmath>
using namespace std;

struct Point {
    int x_coordinate;
    int y_coordinate;
    int z_coordinate;
};

Point Distance(Point a, Point b) {
    int xdistance = b.x_coordinate - a.x_coordinate;
    double xdistance_squared = pow(xdistance, 2);

    int ydistance = b.y_coordinate - a.y_coordinate;
    double ydistance_squared = pow(ydistance, 2);

    int zdistance = b.z_coordinate - a.z_coordinate;
    double zdistance_squared = pow(zdistance, 2);

    int before_rooting = xdistance_squared + ydistance_squared + zdistance;

    cout << "The distance between Point A and Point B in 3D Space is: " << endl;
    cout << sqrt(before_rooting) << endl;
}


int main() {
    Point a, b;
    a.x_coordinate = 1;
    a.y_coordinate = 2;
    a.z_coordinate = 3;

    b.x_coordinate = 2;
    b.y_coordinate = 3;
    b.z_coordinate = 4;

    Distance(a, b);

    return 0;
}
