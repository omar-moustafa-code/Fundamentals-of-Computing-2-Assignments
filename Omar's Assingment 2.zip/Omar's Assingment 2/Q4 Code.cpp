#include <iostream>
#include <stdio.h>
using namespace std;

void StringToASCII(string str) {
    int size = str.size();
    int *dynamic_array = new int(size);


    for (int i = 0; i < size; i++) {
        dynamic_array[i] =
    }


    for (int i = 0; i < size; i++) {
        cout << dynamic_array[i] << "\t";
    }
    cout << endl;
}


int main() {
    std::cout << "Hello, World!" << std::endl;

    string my_str = "ABC";



    return 0;
}
