#include <iostream>
#include <cmath>
using namespace std;

double CubicRoot(double x, double e);

int main() {
    double x, e;

    cout << "Enter a double value for x: " << endl;
    cin >> x;

    cout << "Enter a double value for e: " << endl;
    cin >> e;

    double cubic_root = CubicRoot(x, e);

    cout << "An accurate approximation for the cubic root of " << x << " is: " << cubic_root << endl;

    return 0;
}

double CubicRoot(double x, double e) {
    double y = sqrt(x);

    double y_new = y - ((y * y - x / y) / (2 * y + x / (y * y)));

    while ((abs(y_new - y) / y ) >= e) {
        y = y_new;
        y_new = y - ((y * y - x / y) / (2 * y + x / (y * y)));
    }

    return y_new;
}