#include <iostream>
using namespace std;

float getHoursRate(float &hours, float &rate);
float paycheck(float hours, float rate);
void printCheck(float hours, float rate, float amount_due);

int main() {
    float hours, rate, amount;
    getHoursRate(hours, rate);
    amount = paycheck(hours, rate);
    printCheck(hours, rate, amount);
    return 0;
}

float getHoursRate(float &hours, float &rate) {
    cout << "Enter the hours worked: " << endl;
    cin >> hours;
    cout << "Enter the rate per hour: " << endl;
    cin >> rate;
}

float paycheck(float hours, float rate) {
    float amount_due;
    if (hours <= 40) {
        amount_due = hours * rate;
    } else {
        float new_rate = 1.5 * rate;
        amount_due = hours * new_rate;
    }
    return amount_due;
}

void printCheck(float hours, float rate, float amount_due) {
    cout << "Hours Worked: " << hours << endl;
    cout << "Rate Per Hour: " << rate << endl;
    cout << "Amount Due: " << amount_due << endl;
}