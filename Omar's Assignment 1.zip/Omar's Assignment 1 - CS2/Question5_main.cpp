#include <iostream>
using namespace std;

int sum();
void decision(int sum_of_rolls);

int main() {
    int response;
    cout << "Would you like to play a game of Craps?" << endl;
    cin >> response; // responses are either 1 as in yes or 0 as in no

    if (response == 1) {
        int rolls_sum = sum();
        cout << "The sum of the rolls is: " << rolls_sum << endl;
        decision(rolls_sum);
    }

    cout << "Would you like to play again?" << endl;
    cin >> response;

    while (response == 1) {
        int rolls_sum = sum();
        cout << "The sum of the rolls is: " << rolls_sum << endl;
        decision(rolls_sum);
        cout << "Would you like to play again?" << endl;
        cin >> response;
    }

    cout << "Game Over. " << endl;

    return 0;
}

int sum() {
    int first_roll = rand() % 6 + 1;
    int second_roll = rand() % 6 + 1;
    int sum_of_rolls = first_roll + second_roll;
    return sum_of_rolls;
}

void decision(int sum_of_rolls) {
    int budget;
    int bet;
    cout << "How much is your budget?" << endl;
    cin >> budget;
    cout << "How much are you willing to bet?" << endl;
    cin >> bet;

    if (bet > budget) {
        cout << "This amount is invalid. Please enter an amount less than your budget: " << endl;
        cin >> bet;
        cout << "Very well. Best of luck!" << endl;
    } else {
        cout << "Very well. Best of luck!" << endl;
    }

    if (sum_of_rolls == 7 || sum_of_rolls == 11) {
        cout << "You lost: $" << bet << endl;
    } else if (sum_of_rolls == 2 || sum_of_rolls == 3 || sum_of_rolls == 12) {
        cout << "You win! Now you have $" << bet*2 << endl;
    } else {
        cout << "No loss or gain! Still have $" << bet << endl;
    }
}
