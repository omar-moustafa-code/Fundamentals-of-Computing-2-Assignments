#include <iostream>
using namespace std;

void swap(int &x, int &y);
void readPair(int x, int y);
bool multiple(int x, int y);

int main() {
    int x = 5;
    int y = 7;

    cout << "Before any swapping:" << endl;
    cout << "x = " << x << "\n" << "y = " << y << endl;

    cout << "-------------------------------------------" << endl;

    cout << "Swap: " << endl;
    swap(x, y);
    cout << "x = " << x << "\n" << "y = " << y << endl;

    cout << "-------------------------------------------" << endl;

    readPair(x, y);

    cout << "-------------------------------------------" << endl;

    if(multiple(x, y)) {
        cout << "y is indeed a multiple of x!" << endl;
    } else {
        cout << "y is NOT a multiple of x!" << endl;
    }

    return 0;
}

void swap(int &x, int &y) {
    int temp = x;
    x = y;
    y = temp;
}

void readPair(int x, int y) {
    if (x > 0 && y > 0) {
        if (y < x) {
            swap(x, y);
            cout << "y is less than x so they must be swapped: " << endl;
            cout << "x = " << x << "\n" << "y = " << y << endl;
        }
    } else {
        cout << "At least one of the values is less than zero!" << endl;
    }
}

bool multiple(int x, int y) {
    if (y % x == 0) {
        return true;
    } else {
        return false;
    }
}
