#include <iostream>
using namespace std;

void ArrangeDisks(int a[], int n);

int main() {

    int array[] = {1, 0, 1, 0, 1, 1, 0, 0};
    int n = 4;
    ArrangeDisks(array, n);

    return 0;
}

void ArrangeDisks(int a[], int n) {
    int array_size = 2*n;
    int position = 0;

    cout << "Here is the original array:" << endl;
    for (int i = 0; i < array_size; i++) {
        cout << a[i] << "\t";
    }
    cout << endl;

    cout << " " << endl;

    for (int i = 0; i < array_size; i++) {
        if (a[i] != 1) {
           a[position++] = a[i];
        }
    }

    while (position < array_size) {
        a[position++] = 1;
    }

    cout << "Here is the new arranged array:" << endl;
    for (int i = 0; i < array_size; i++) {
        cout << a[i] << "\t";
    }
    cout << endl;

    cout << " " << endl;
}