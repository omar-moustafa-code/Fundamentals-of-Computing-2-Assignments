#include <iostream>
using namespace std;

struct Student {
    int ID;
    int Grade1;
    int Grade2;
    int Grade3;
    int Grade4;
    int Grade5;
};

struct Average {
    int Average_Grade;
};

void InputData(Student Array[], int num) {
    for (int i = 0; i < num; i++) {
        cout << "Enter ID: " << endl;
        cin >> Array[i].ID;
        cout << "Enter Grade 1" << endl;
        cin >> Array[i].Grade1;
        cout << "Enter Grade 2" << endl;
        cin >> Array[i].Grade2;
        cout << "Enter Grade 3" << endl;
        cin >> Array[i].Grade3;
        cout << "Enter Grade 4" << endl;
        cin >> Array[i].Grade4;
        cout << "Enter Grade 5" << endl;
        cin >> Array[i].Grade5;
    }
}

void PrintID_and_AverageGrade(Student Array[], int num, Average avg[]) {
    int exam_count = 5;
    for (int i = 0; i < num; i++) {
        avg[i].Average_Grade = (Array[i].Grade1 + Array[i].Grade2 + Array[i].Grade3 + Array[i].Grade4 + Array[i].Grade5) / exam_count;
        cout << "Information of Student " << i+1 << ": " << endl;
        cout << "Their ID Is: " << Array[i].ID << endl;
        cout << "Their Average Grade Is: " << avg[i].Average_Grade << endl;
    }
}

void WorstAverageGrade(Student Array[], int num, Average avg[]) {
    int minimum = 10000;
    for (int i = 0; i < num; i++) {
        if (avg[i].Average_Grade < minimum) {
            minimum = avg[i].Average_Grade;
        }
    }
    cout << "The Worst Average Grade is: " << minimum << endl;

    for (int i = 0; i < num; i++) {
        if (avg[i].Average_Grade == minimum) {
            cout << "The ID of the Student with the Worst Average is: " << Array[i].ID << endl;
        }
    }
}

int main() {

    Student Arr[40];
    int x = 1;
    Average Avg[40];
    InputData(Arr, x);
    PrintID_and_AverageGrade(Arr, x, Avg);
    WorstAverageGrade(Arr, x, Avg);

    return 0;
}
